$(document).ready(function(){

	$('#rightPanel').hide();

	/* Highlight categories */
	$('.catergories .cat').click(function(){

		$('.catergories .cat').removeClass('active');

		$(this).addClass('active');

	});

	/* Toggle right panel */

	$('.thumb-cont').click(function(){

		/* Highligh thumbs */
		$('.thumb-cont').removeClass('active');
		$(this).addClass('active');

		/* Show right panel */
		$('#rightPanel').show();
		$('#toggleWidth').removeClass('col-sm-12').addClass('col-sm-9');


	});


});